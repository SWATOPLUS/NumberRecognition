﻿using System;
using System.Drawing;

namespace NumberRecognition
{
    public static class DoubleArrayExtensions
    {
        public static Bitmap ToBitmap(this double[,] arr, int segmentSize)
        {
            var width = arr.GetLength(0);
            var height = arr.GetLength(1);

            var bitmap = new Bitmap(width * segmentSize, height * segmentSize);

            for (int i = 0; i < width; i++)
            {
                for (int j = 0; j < height; j++)
                {
                    var color = arr[i, j].ToColor();

                    for (int x = 0; x < segmentSize; x++)
                    {
                        for (int y = 0; y < segmentSize; y++)
                        {
                            bitmap.SetPixel(i * segmentSize + x, j * segmentSize + y, color);
                        }
                    }
                }
            }

            return bitmap;
        }

        private static Color ToColor(this double value)
        {
            var brightness = (int)Math.Round(value * 255);

            if (brightness < 0)
            {
                return Color.Red;
            }

            return Color.FromArgb(brightness, brightness, brightness);
        }
    }
}
