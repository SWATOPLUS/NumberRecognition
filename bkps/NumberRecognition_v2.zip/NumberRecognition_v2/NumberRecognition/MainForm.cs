﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Windows.Forms;

namespace NumberRecognition
{
    public partial class MainForm : Form
    {
        public MainForm()
        {
            InitializeComponent();
        }

        private void MainForm_Load(object sender, EventArgs e)
        {
            var bitmap = new Bitmap("img2.png");

            SourceImage.Image = bitmap;
            //ProcessedImage.Image = ApplySegmentFunc(bitmap, 5, x => CalcSingePixel(x, GreyDistance));

            var pic = new Picture(bitmap);

            double func(Picture picture) => (ImageManipulate.CalcNeighborPixel(picture, ImageManipulate.Contrast));

            var segmentSize = 8;
            var segY = 6;
            var segX = segY * 3;
            var map = pic.ApplySegmentFunc(segmentSize, func);
            var (x, y) = ImageManipulate.GetRect(map, segX, segY);
            map[x, y] = map[x + segX, y] = map[x, y + segY] = map[x + segX, y + segY] = -1;
            var mapBitmap = map.ToBitmap(segmentSize);
            ProcessedImage.Image = mapBitmap;

            var plateBitmap = bitmap.Clone(new Rectangle(x * segmentSize, y * segmentSize, segX * segmentSize, segY * segmentSize), mapBitmap.PixelFormat);
            PlateImage.Image = plateBitmap;
            var binBitmap = ImageManipulate.Binarize(plateBitmap);
            BinarizedImage.Image = binBitmap;

            CuttedImage.Image = ImageManipulate.CutOffMiddle(new Picture(binBitmap), 0.3).ToBitmap();

            var normalizeAngle = ImageManipulate.NormalizeAngle(binBitmap); //0,05
            var normalizedBitmap = binBitmap.RotateImage(normalizeAngle * 180.0 / Math.PI );
            NormalizedImage.Image = normalizedBitmap;
            var fixedPic= ImageManipulate.FixBorder(new Picture(normalizedBitmap));
            FixedImage.Image = fixedPic.ToBitmap();
            var clearedPic = ImageManipulate.ClearBorder(fixedPic);
            ClearedImage.Image = clearedPic.ToBitmap();
        }
    }
}
