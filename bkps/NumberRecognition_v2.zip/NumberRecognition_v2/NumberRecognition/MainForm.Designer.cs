﻿namespace NumberRecognition
{
    partial class MainForm
    {
        /// <summary>
        /// Обязательная переменная конструктора.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Освободить все используемые ресурсы.
        /// </summary>
        /// <param name="disposing">истинно, если управляемый ресурс должен быть удален; иначе ложно.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Код, автоматически созданный конструктором форм Windows

        /// <summary>
        /// Требуемый метод для поддержки конструктора — не изменяйте 
        /// содержимое этого метода с помощью редактора кода.
        /// </summary>
        private void InitializeComponent()
        {
            this.SourceImage = new System.Windows.Forms.PictureBox();
            this.ProcessedImage = new System.Windows.Forms.PictureBox();
            this.PlateImage = new System.Windows.Forms.PictureBox();
            this.BinarizedImage = new System.Windows.Forms.PictureBox();
            this.CuttedImage = new System.Windows.Forms.PictureBox();
            this.NormalizedImage = new System.Windows.Forms.PictureBox();
            this.FixedImage = new System.Windows.Forms.PictureBox();
            this.ClearedImage = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.SourceImage)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.ProcessedImage)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.PlateImage)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.BinarizedImage)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.CuttedImage)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.NormalizedImage)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.FixedImage)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.ClearedImage)).BeginInit();
            this.SuspendLayout();
            // 
            // SourceImage
            // 
            this.SourceImage.Location = new System.Drawing.Point(12, 12);
            this.SourceImage.Name = "SourceImage";
            this.SourceImage.Size = new System.Drawing.Size(750, 500);
            this.SourceImage.TabIndex = 0;
            this.SourceImage.TabStop = false;
            // 
            // ProcessedImage
            // 
            this.ProcessedImage.Location = new System.Drawing.Point(764, 12);
            this.ProcessedImage.Name = "ProcessedImage";
            this.ProcessedImage.Size = new System.Drawing.Size(750, 500);
            this.ProcessedImage.TabIndex = 1;
            this.ProcessedImage.TabStop = false;
            // 
            // PlateImage
            // 
            this.PlateImage.Location = new System.Drawing.Point(12, 518);
            this.PlateImage.Name = "PlateImage";
            this.PlateImage.Size = new System.Drawing.Size(200, 100);
            this.PlateImage.TabIndex = 2;
            this.PlateImage.TabStop = false;
            // 
            // BinarizedImage
            // 
            this.BinarizedImage.Location = new System.Drawing.Point(218, 518);
            this.BinarizedImage.Name = "BinarizedImage";
            this.BinarizedImage.Size = new System.Drawing.Size(200, 100);
            this.BinarizedImage.TabIndex = 3;
            this.BinarizedImage.TabStop = false;
            // 
            // CuttedImage
            // 
            this.CuttedImage.Location = new System.Drawing.Point(424, 518);
            this.CuttedImage.Name = "CuttedImage";
            this.CuttedImage.Size = new System.Drawing.Size(200, 100);
            this.CuttedImage.TabIndex = 4;
            this.CuttedImage.TabStop = false;
            // 
            // NormalizedImage
            // 
            this.NormalizedImage.Location = new System.Drawing.Point(630, 518);
            this.NormalizedImage.Name = "NormalizedImage";
            this.NormalizedImage.Size = new System.Drawing.Size(200, 100);
            this.NormalizedImage.TabIndex = 5;
            this.NormalizedImage.TabStop = false;
            // 
            // FixedImage
            // 
            this.FixedImage.Location = new System.Drawing.Point(836, 518);
            this.FixedImage.Name = "FixedImage";
            this.FixedImage.Size = new System.Drawing.Size(200, 100);
            this.FixedImage.TabIndex = 6;
            this.FixedImage.TabStop = false;
            // 
            // ClearedImage
            // 
            this.ClearedImage.Location = new System.Drawing.Point(1042, 518);
            this.ClearedImage.Name = "ClearedImage";
            this.ClearedImage.Size = new System.Drawing.Size(200, 100);
            this.ClearedImage.TabIndex = 7;
            this.ClearedImage.TabStop = false;
            // 
            // MainForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1517, 648);
            this.Controls.Add(this.ClearedImage);
            this.Controls.Add(this.FixedImage);
            this.Controls.Add(this.NormalizedImage);
            this.Controls.Add(this.CuttedImage);
            this.Controls.Add(this.BinarizedImage);
            this.Controls.Add(this.PlateImage);
            this.Controls.Add(this.ProcessedImage);
            this.Controls.Add(this.SourceImage);
            this.Name = "MainForm";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.MainForm_Load);
            ((System.ComponentModel.ISupportInitialize)(this.SourceImage)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.ProcessedImage)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.PlateImage)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.BinarizedImage)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.CuttedImage)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.NormalizedImage)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.FixedImage)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.ClearedImage)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.PictureBox SourceImage;
        private System.Windows.Forms.PictureBox ProcessedImage;
        private System.Windows.Forms.PictureBox PlateImage;
        private System.Windows.Forms.PictureBox BinarizedImage;
        private System.Windows.Forms.PictureBox CuttedImage;
        private System.Windows.Forms.PictureBox NormalizedImage;
        private System.Windows.Forms.PictureBox FixedImage;
        private System.Windows.Forms.PictureBox ClearedImage;
    }
}

