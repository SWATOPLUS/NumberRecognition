using System;
using Xunit;
using System.Linq;

namespace ToolsTests
{
    public class UnitTest1
    {
        [Fact]
        public void Test1()
        {
            var max = 0.0;

            foreach (int x in Enumerable.Range(0, 255))
            {
                foreach (int y in Enumerable.Range(0, 255))
                {
                    foreach (int z in Enumerable.Range(0, 255))
                    {
                        var avg = (x + y + z) / 3.0;
                        var res = (Math.Abs(avg - x) + Math.Abs(avg - y) + Math.Abs(avg - z));

                        if (res > max)
                        {
                            max = res;
                        }
                    }
                }
            }

            throw new Exception(max.ToString());
        }
    }
}
