﻿namespace ImageRecognition
{
    public class PatternInfo
    {
        public string Name { get; set; }
        public double[,] Pattern { get; set; }
    }
}
